export const DEFAULT_PROMPTS = {
  // --- 1. ENRICH (Làm giàu thẻ) ---
  enrich_word: `Phân tích từ vựng "{term}" ({lang}->Vi). Các trường JSON yêu cầu: term, pronunciation, definition (dịch nghĩa cực ngắn dưới 6 từ, không giải thích), partOfSpeech (Từ loại bằng Tiếng Việt), topic (BẮT BUỘC CHỌN 1 TRONG 9 GIÁ TRỊ: 'Self & Body', 'Social Connections', 'Living Spaces', 'The Natural World', 'Food & Health', 'Daily Life & Leisure', 'School & Career', 'Travel & Exploration', 'Other'), analysis (Giải thích cách dùng ngắn gọn), example (câu chứa từ + dịch), image_keyword (Bắt buộc bằng Tiếng Anh).`,


  enrich_sentence: `Phân tích CÂU VĂN "{term}" ({lang}->Vi). Các trường JSON yêu cầu: term, pronunciation, definition (Tiếng Việt), partOfSpeech (Ghi là "Câu văn"), topic (BẮT BUỘC CHỌN 1 TRONG 9 GIÁ TRỊ: 'Self & Body', 'Social Connections', 'Living Spaces', 'The Natural World', 'Food & Health', 'Daily Life & Leisure', 'School & Career', 'Travel & Exploration', 'Other'), analysis (cấu trúc ngữ pháp), example (Tạo 1 câu ví dụ có cấu trúc tương tự + Dịch), image_keyword (Bắt buộc bằng Tiếng Anh), grammar_type (ĐỊNH HƯỚNG GẮN NHÃN:\n1. Nếu câu mang cấu trúc bình thường, hãy trả về mảng rỗng [].\n2. Hãy chọn lọc 1 đến 2 mã cốt lõi nhất phản ánh đúng đặc trưng ngữ pháp của câu.\n3. TIẾNG TRUNG chọn trong: [zh_hsk1_pronoun_gender, zh_hsk1_pronoun_location, zh_hsk1_question_quantity, zh_hsk1_number_liang, zh_hsk1_measure_mismatch, zh_hsk1_negation_bumei, zh_hsk1_modal_ability, zh_hsk1_verb_direction, zh_hsk1_adj_predicate_shi, zh_hsk1_particle_de_redundant, zh_hsk1_exclam_tai_le, zh_hsk1_question_ma_ne, zh_hsk1_serial_verb_order, zh_hsk1_time_order, zh_hsk1_place_order, zh_hsk2_pronoun_ta_mismatch, zh_hsk2_pronoun_mei_measure, zh_hsk2_number_er_liang, zh_hsk2_measure_mismatch, zh_hsk2_adv_you_zai, zh_hsk2_adv_jiu_pos, zh_hsk2_prep_gei_order, zh_hsk2_conj_missing_pair, zh_hsk2_conj_logic_clash, zh_hsk2_state_comp_missing_verb, zh_hsk2_state_comp_obj_pos, zh_hsk2_compare_bi_adv, zh_hsk2_prog_zhengzai_clash, zh_hsk2_approx_duo_less10, zh_hsk2_approx_duo_more10, zh_hsk2_prep_cong_li, zh_hsk2_aspect_zhe_le, zh_hsk_separable_obj, zh_hsk_adv_zhongyu, zh_hsk_adv_degree, zh_hsk_prep_mismatch, zh_hsk_conj_mismatch, zh_hsk_noun_space, zh_hsk_rc_negation, zh_hsk_rc_state, zh_hsk_pc_ability, zh_hsk_dc_location, zh_hsk_dc_direction, zh_hsk_ba_indefinite, zh_hsk_ba_result, zh_hsk_bei_reverse, zh_hsk_exist_order, zh_hsk_emph_order, zh_hsk_emph_extreme, zh_hsk_paired_only_if, zh_hsk_paired_as_long_as, zh_hsk_dist_li, zh_hsk_comp_bi, zh_hsk_except_chule].\n4. TIẾNG ANH chọn trong: [pre_a1_article_an, pre_a1_plural_s, pre_a1_tobe_match, pre_a1_this_that, pre_a1_like_plural, pre_a1_commands, pre_a1_adj_order, pre_a1_he_she, pre_a1_have_has, pre_a1_prepositions, pre_a1_yesno_order, pre_a1_can_cant, eng_a1_pres_3rd_person, eng_a1_pres_tobe_verb_clash, eng_a1_pres_auxiliary, eng_a1_adv_frequency_pos, eng_a1_pres_cont_missing_be, eng_a1_pres_cont_base_verb, eng_a1_tense_clash, eng_a1_past_tobe_agreement, eng_a1_past_tobe_verb_clash, eng_a1_past_missing_ed, eng_a1_modal_can_to, eng_a1_modal_can_s, eng_a1_would_like, eng_a1_possessive_adj, eng_a1_demonstrative_clash, eng_a1_uncountable_plural, eng_a1_prep_time, eng_a1_prep_place_vn, eng_a1_conjunction_logic, eng_a1_wh_question_match, eng_a1p_tense_clash, eng_a1p_past_ed, eng_a1p_past_double, eng_a1p_past_be_vs_do, eng_a1p_comp_double, eng_a1p_comp_irregular, eng_a1p_comp_than, eng_a1p_quant_some_any, eng_a1p_quant_much_many, eng_a1p_quant_a_lot_of, eng_a1p_conj_because_so, eng_a1p_adv_very_verb, eng_a1p_adv_too_much, eng_a1p_job_article, eng_a1p_modal_to, eng_a1p_modal_s, eng_a1p_emotion_ed_ing, eng_a1p_tag_question, eng_a1p_phrasal_prep, eng_a1p_time_quarter, eng_a2_past_interrupt, eng_a2_pres_perf_form, eng_a2_pres_perf_ever, eng_a2_future_will_going, eng_a2_although_but, eng_a2_because_so, eng_a2_if_type1_will, eng_a2_when_while_swap, eng_a2_adv_of_manner, eng_a2_comparative_double, eng_a2_superlative_missing_the, eng_a2_irregular_adj, eng_a2_modal_plus_to, eng_a2_modal_plus_ving, eng_a2_have_to_conjugation, eng_a2_mustn_dont_have_to, eng_a2_much_many, eng_a2_few_little, eng_a2_make_do_swap, eng_a2_phrasal_prep, eng_article_an, eng_plural_s, eng_present_cont, eng_this_these, eng_past_irregular, eng_comparative_double, eng_much_many, eng_since_for, eng_passive_missing_be, eng_vietglish_collocation].\nVui lòng chỉ sử dụng các mã có sẵn trong danh sách trên).`,


  // --- 2. TRẮC NGHIỆM (QUIZ) ---
  quiz_word: `Bạn là chuyên gia thiết kế bài tập ngôn ngữ. Hãy tạo 3 đáp án nhiễu cho từ vựng: "{baseText}" (Nghĩa đúng: "{targetText}").\nĐỊNH HƯỚNG SÁNG TẠO: Hãy tạo ra các đáp án nhiễu cùng từ loại hoặc cùng chủ đề với từ gốc để mang lại tính thử thách logic cao nhất cho người học.`,


  // Alias dự phòng tương thích ngược với hàm fetchAiDistractors
  quizword: `Bạn là chuyên gia thiết kế bài tập ngôn ngữ. Hãy tạo 3 đáp án nhiễu cho từ vựng: "{baseText}" (Nghĩa đúng: "{targetText}").\nĐỊNH HƯỚNG SÁNG TẠO: Hãy tạo ra các đáp án nhiễu cùng từ loại hoặc cùng chủ đề với từ gốc để mang lại tính thử thách logic cao nhất cho người học.`,


  quiz_sentence: `Bạn là chuyên gia thiết kế bài tập ngôn ngữ. Hãy tạo 3 đáp án nhiễu cho câu văn: "{baseText}" (Bản dịch đúng: "{targetText}").\nKỶ LUẬT CẤU TRÚC: Cả 3 đáp án nhiễu phải là NHỮNG CÂU HOÀN CHỈNH. Hãy giữ trọn vẹn độ dài và không được cắt xén câu để tránh làm lộ đáp án.\nĐỊNH HƯỚNG SÁNG TẠO: Bạn có thể tự do bay bổng biến tấu chủ ngữ, động từ, hoặc thời gian, tính từ... để tạo ra những tình huống sai lệch thú vị và tự nhiên nhất so với bản dịch đúng.`,


  // --- 3. NỐI Ô (MATCH) ---
  match_word: `Tạo 1 nghĩa sai (bằng Tiếng Việt) cho MỖI từ sau: {itemsText}.\nĐỊNH HƯỚNG SÁNG TẠO: Nghĩa sai nên thuộc cùng nhóm chủ đề/lĩnh vực với từ gốc nhưng mang ý nghĩa hoàn toàn khác. Hãy lừa học viên bằng tư duy logic thay vì tạo ra các từ sai chính tả tiếng Việt.`,


  match_sentence: `Tạo 1 bản dịch sai (bằng Tiếng Việt) cho MỖI câu sau: {itemsText}.\nĐỊNH HƯỚNG SÁNG TẠO: Bản dịch sai cần được viết vô cùng trôi chảy và xuôi tai, nhưng ẩn chứa sự sai lệch khéo léo về chủ thể, mốc thời gian hoặc đảo ngược tính chất của sự việc.`,


  // --- 4. ĐIỀN TỪ (FILL BLANK) ---
  fillblank_sentence: `Đóng vai một giáo viên, phân tích câu "{term}" ({lang}).\nĐỊNH HƯỚNG SÁNG TẠO:\n1. Hãy tìm một từ vựng mang ý nghĩa then chốt (Danh từ, Động từ, Tính từ) để đục lỗ. Vui lòng bỏ qua các dấu câu, con số hay các trợ từ ngữ pháp cơ bản để bài tập hay hơn.\n2. Thay thế từ đó bằng chuỗi "[__________]".\n3. Sáng tạo 3 đáp án nhiễu bằng {lang}. Các đáp án nhiễu nên hợp lệ về cấu trúc ngữ pháp nhưng sai lệch về ngữ cảnh để lừa học viên.\n4. Trả về JSON: "displaySentence" (câu đã đục lỗ), "targetWord" (từ đúng đã bị đục), "distractors" (mảng chứa 3 đáp án nhiễu), "hint" (Dịch nghĩa câu: "{definition}").`,


  // --- 5. GIẢI THÍCH NGỮ PHÁP (GRAMMAR) ---
  grammar: `Đóng vai một gia sư tận tâm, hãy phân tích ngữ pháp của câu sau: '{sentence}' ({lang}). Ngắn gọn, súc tích và dễ hiểu.`
};


export default DEFAULT_PROMPTS;
